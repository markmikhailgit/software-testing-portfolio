# E-Commerce Testing Project

Contains test cases, bug reports, and summary.